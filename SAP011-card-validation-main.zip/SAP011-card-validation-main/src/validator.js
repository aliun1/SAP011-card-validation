const validator = {
  // ...
};

export default validator;
