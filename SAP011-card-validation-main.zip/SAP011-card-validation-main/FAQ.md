# FAQ (preguntas frecuentes)

- [Por qué usar html semántico](https://youtu.be/vRqQRrULSxI)
- [Diferencia entre datos atómicos y estructurados](https://www.todojs.com/tipos-datos-javascript-es6/)
- [Para qué sirve el ESLint](https://es.paperblog.com/que-es-eslint-y-por-que-deberias-usarlo-5393037/)
- [Para qué sirven las pruebas unitarias](http://oscarmoreno.com/pruebas-unitarias/)
- Tengo que testear toda mi función

> En líneas generales, sí, esto es, sabiendo que queremos que tu función haga pocas
cosas. Si tu función hace varias cosas al mismo tiempo el problema sería otro
y primero tendrías que dividir esa funcionalidad en varias funciones y escribir
un test para cada una.
